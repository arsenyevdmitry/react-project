import './App.css';

function App() {

  return (
    <div>Проект</div>
 );
}

export default App;